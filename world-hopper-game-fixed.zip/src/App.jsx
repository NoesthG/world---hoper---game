import React from 'react';

const App = () => {
  return (
    <div>
      <h1>Welcome to World Hopper Game!</h1>
      <p>Explore different countries and test your English level!</p>
    </div>
  );
};

export default App;